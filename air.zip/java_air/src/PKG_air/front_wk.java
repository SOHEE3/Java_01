package PKG_air;

public interface front_wk {
	public void Front();
}
