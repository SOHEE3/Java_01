package PKG_air;

public interface weekend2 {
	public void Weekend();
}
