package PKG_Product;

public class foreign extends A_Product {

	private String forName;

	public foreign(String pName, int pPrice, String forName) {
		super(pName, pPrice);
		this.forName = forName;
	}

	@Override // �ؿ� �׽����� 20%
	public double getTiketPrice() {

		int pPrice = super.getPPrice();

		double f_salePrice = pPrice * 0.8;

		return f_salePrice;
	}

	@Override
	public String NAME() {

		return this.forName;

	}

}
