package PKG_Product;

public class domestic extends A_Product{

	private String domName;
	
	public domestic( String pName, int pPrice, String domName) {
		super(pName, pPrice);
		this.domName = domName;		
	}
	
	
	// ���� ����x
	@Override
	public double getTiketPrice() {
		
		int pPrice = super.getPPrice();
		
		double d_salePrice = (double)pPrice;		
		return d_salePrice;
		
	}
}
